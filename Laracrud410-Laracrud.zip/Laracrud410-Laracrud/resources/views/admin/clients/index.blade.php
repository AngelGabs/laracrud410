@extends('layout.main_template')

@section('content')
<p>Index Cliente</p>
@endsection

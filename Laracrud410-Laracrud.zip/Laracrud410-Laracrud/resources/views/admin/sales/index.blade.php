@extends('layout.main_template')
@section('content')
<p>Index Ventas</p>
@endsection